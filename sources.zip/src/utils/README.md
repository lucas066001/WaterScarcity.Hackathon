# ./src/utils

Here you'll find imported [provided utils scripts](https://github.com/DavidMedernach/Hackathon-Water-Scarcity/tree/main/src/utils) from original repo.

---